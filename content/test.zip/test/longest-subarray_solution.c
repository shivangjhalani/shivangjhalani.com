#include <stdio.h>
#include <stdlib.h>

// Placeholder function for the core logic
int findLongestSubarray(int n, int *arr, int limit) {
  int max_length = 0;
  int current_length = 0;

  for (int i = 0; i < n; i++) {
    if (arr[i] <= limit) {
      current_length++;
      if (current_length > max_length) {
        max_length = current_length;
      }
    } else {
      current_length = 0;
    }
  }

  return max_length;
}

int main() {
  // --- Test Case 1 (From image) ---
  printf("Test Case 1:\n");
  int arr1[] = {1, 2, 3, 4, 5};
  int n1 = sizeof(arr1) / sizeof(arr1[0]);
  int limit1 = 3;
  int result1 = findLongestSubarray(n1, arr1, limit1);
  printf("Inputs: arr=[1, 2, 3, 4, 5], limit=3\n");
  printf("Expected: 3\n"); // Longest subarray with elements <= 3 is [1, 2, 3]
  printf("Actual: %d\n\n", result1);

  // --- Test Case 2 (From image) ---
  printf("Test Case 2:\n");
  int arr2[] = {3, 1, 2, 1};
  int n2 = sizeof(arr2) / sizeof(arr2[0]);
  int limit2 = 2;
  int result2 = findLongestSubarray(n2, arr2, limit2);
  printf("Inputs: arr=[3, 1, 2, 1], limit=2\n");
  printf("Expected: 3\n"); // Longest subarray with elements <= 2 is [1, 2, 1]
  printf("Actual: %d\n\n", result2);

  // --- Test Case 3 (Additional test) ---
  printf("Test Case 3:\n");
  int arr3[] = {5, 6, 7, 5, 2, 3, 1, 2, 3};
  int n3 = sizeof(arr3) / sizeof(arr3[0]);
  int limit3 = 4;
  int result3 = findLongestSubarray(n3, arr3, limit3);
  printf("Inputs: arr=[5, 6, 7, 5, 2, 3, 1, 2, 3], limit=4\n");
  printf("Expected: 5\n"); // Longest subarray with elements <= 4 is [2, 3, 1,
                           // 2, 3]
  printf("Actual: %d\n\n", result3);

  return 0;
}
