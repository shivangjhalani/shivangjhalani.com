#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* decryptPassword(char* s) {
    int len = strlen(s);
    char* result = strdup(s);
    int write_pos = 0;
    int num_stack[1000];
    int num_count = 0;
    
    // Collect leading numbers
    int i = 0;
    while (i < len && s[i] >= '1' && s[i] <= '9') {
        num_stack[num_count++] = s[i] - '0';
        i++;
    }
    
    // Process string
    for (; i < len; i++) {
        if (s[i] == '0' && num_count > 0) {
            result[write_pos++] = num_stack[--num_count] + '0';
        } else if (s[i] == '*') {
            // Swap previous two characters
            char temp = result[write_pos - 2];
            result[write_pos - 2] = result[write_pos - 1];
            result[write_pos - 1] = temp;
        } else if (s[i] != '0') {
            result[write_pos++] = s[i];
        }
    }
    
    result[write_pos] = '\0';
    return result;
}

void runTestCase(char* input, char* expected) {
    printf("\nInput: %s\n", input);
    char* result = decryptPassword(input);
    printf("Expected Output: %s\n", expected);
    printf("Actual Output: %s\n", result);
    printf("Result: %s\n", strcmp(result, expected) == 0 ? "✓ PASSED" : "✗ FAILED");
    free(result);
}

int main() {
    // Test Case 1
    runTestCase("51Pa*0Lp*0e", "aP1pL5e");
    
    // Test Case 2
    runTestCase("pTo*Ta*O", "TaTop");
    
    return 0;
}
