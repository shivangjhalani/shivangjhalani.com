#include <stdio.h>
#include <stdlib.h>

// Function to count subarrays with sum equal to k
long long countSubarrays(int n, int* arr, int k) {
    long long count = 0;
    
    // Brute force approach: check all subarrays
    for (int i = 0; i < n; i++) {
        long long sum = 0;
        for (int j = i; j < n; j++) {
            sum += arr[j];
            if (sum == k) {
                count++;
            }
        }
    }
    
    return count;
}

int main() {
    // --- Test Case 1 ---
    printf("Test Case 1:\n");
    int arr1[] = {3, 0, 3, 0, 0};
    int n1 = sizeof(arr1) / sizeof(arr1[0]);
    int k1 = 3;
    long long result1 = countSubarrays(n1, arr1, k1);
    printf("Inputs: arr=[3, 0, 3, 0, 0], k=3\n");
    printf("Expected: 6\n"); // Six subarrays with sum 3
    printf("Actual: %lld\n\n", result1);

    // --- Test Case 2 ---
    printf("Test Case 2:\n");
    int arr2[] = {1, 2, 1, 2, 1};
    int n2 = sizeof(arr2) / sizeof(arr2[0]);
    int k2 = 3;
    long long result2 = countSubarrays(n2, arr2, k2);
    printf("Inputs: arr=[1, 2, 1, 2, 1], k=3\n");
    printf("Expected: 4\n"); // Four subarrays with sum 3
    printf("Actual: %lld\n\n", result2);

    // --- Test Case 3 ---
    printf("Test Case 3:\n");
    int arr3[] = {1, -1, 1, -1, 1};
    int n3 = sizeof(arr3) / sizeof(arr3[0]);
    int k3 = 0;
    long long result3 = countSubarrays(n3, arr3, k3);
    printf("Inputs: arr=[1, -1, 1, -1, 1], k=0\n");
    printf("Expected: 4\n"); // Four subarrays with sum 0
    printf("Actual: %lld\n\n", result3);

    return 0;
}
