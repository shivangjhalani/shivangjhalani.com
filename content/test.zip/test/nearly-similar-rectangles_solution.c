#include <stdio.h>
#include <stdlib.h>
#include <string.h> // For memset or memcpy if needed

// Helper function for GCD if needed for simplifying ratios
long long gcd(long long a, long long b) {
    while (b) {
        a %= b;
        long long temp = a;
        a = b;
        b = temp;
    }
    return a;
}

// Define a structure for the simplified ratio to use in counting
typedef struct {
    long long num; // Simplified numerator (e.g., length)
    long long den; // Simplified denominator (e.g., width)
} Ratio;

// Comparison function for sorting ratios if needed (alternative to hash map)
int compareRatios(const void* a, const void* b) {
    Ratio* rA = (Ratio*)a;
    Ratio* rB = (Ratio*)b;
    if (rA->num * rB->den != rB->num * rA->den) {
        // Compare cross products to avoid floating point issues
        return (rA->num * rB->den < rB->num * rA->den) ? -1 : 1;
    }
    return 0; // Ratios are equal
}

// Function signature updated based on typical inputs for this problem
// sides: 2D array where sides[i][0] is length, sides[i][1] is width
// n: number of rectangles (rows in sides)
// Returns the number of pairs of nearly similar rectangles
long long countNearlySimilarRectangles(int n, long long** sides) {
    if (n < 2) {
        return 0;
    }

    Ratio* ratios = (Ratio*)malloc(n * sizeof(Ratio));
    if (!ratios) return -1; // Error

    // Calculate simplified ratios
    for (int i = 0; i < n; ++i) {
        long long common = gcd(sides[i][0], sides[i][1]);
        ratios[i].num = sides[i][0] / common;
        ratios[i].den = sides[i][1] / common;
    }

    // Sort ratios to group identical ones together
    qsort(ratios, n, sizeof(Ratio), compareRatios);

    long long count = 0;
    long long current_streak = 1;
    for (int i = 1; i < n; ++i) {
        // Check if current ratio is same as previous one
        if (ratios[i].num == ratios[i-1].num && ratios[i].den == ratios[i-1].den) {
            current_streak++;
        } else {
            // End of a streak of identical ratios. Add pairs from this streak.
            // Number of pairs in a streak of size k is k * (k - 1) / 2
            count += (current_streak * (current_streak - 1)) / 2;
            current_streak = 1; // Start new streak
        }
    }
    // Add pairs from the last streak
    count += (current_streak * (current_streak - 1)) / 2;

    free(ratios);
    return count;
}

int main() {
    // --- Test Case 1 (From image) ---
    printf("Test Case 1:\n");
    long long sides1_data[][2] = {{4, 8}, {15, 30}, {25, 50}};
    long long* sides1[3];
    for(int i=0; i<3; ++i) sides1[i] = sides1_data[i];
    int n1 = 3;
    long long result1 = countNearlySimilarRectangles(n1, sides1);
    printf("Inputs: sides=[[4, 8], [15, 30], [25, 50]]\n");
    printf("Expected: 3\n"); // Ratios are 1/2, 1/2, 1/2. Streak=3. Pairs = 3*(3-1)/2 = 3.
    printf("Actual: %lld\n\n", result1);


    // --- Test Case 2 (From image) ---
    printf("Test Case 2:\n");
    long long sides2_data[][2] = {{2, 2}, {1, 1}, {3, 3}};
     long long* sides2[3];
    for(int i=0; i<3; ++i) sides2[i] = sides2_data[i];
    int n2 = 3;
    long long result2 = countNearlySimilarRectangles(n2, sides2);
    printf("Inputs: sides=[[2, 2], [1, 1], [3, 3]]\n");
    printf("Expected: 3\n"); // Ratios are 1/1, 1/1, 1/1. Streak=3. Pairs = 3*(3-1)/2 = 3.
    printf("Actual: %lld\n\n", result2);

    // --- Test Case 3 (Mixed Ratios) ---
    printf("Test Case 3:\n");
    long long sides3_data[][2] = {{5, 10}, {10, 20}, {1, 3}, {2, 6}, {3, 9}};
    long long* sides3[5];
    for(int i=0; i<5; ++i) sides3[i] = sides3_data[i];
    int n3 = 5;
    long long result3 = countNearlySimilarRectangles(n3, sides3);
    printf("Inputs: sides=[[5, 10], [10, 20], [1, 3], [2, 6], [3, 9]]\n");
    printf("Expected: 4\n"); // Ratios: 1/2, 1/2, 1/3, 1/3, 1/3. Pairs = (2*1/2) + (3*2/2) = 1 + 3 = 4.
    printf("Actual: %lld\n\n", result3);


    return 0;
}
