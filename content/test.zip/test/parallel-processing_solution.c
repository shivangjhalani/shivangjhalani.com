#include <stdio.h>
#include <stdlib.h>

// Function to find minimum processing time
long long processFiles(int* files, int n, int numCores) {
    // Simple implementation: use a greedy approach to assign files to cores
    // Maintain an array to track when each core will be free
    long long* core_times = (long long*)calloc(numCores, sizeof(long long));
    if (!core_times) return -1;
    
    // Process each file by assigning it to the core that will finish earliest
    for (int i = 0; i < n; i++) {
        // Find the core that will be free earliest
        int min_core_index = 0;
        for (int j = 1; j < numCores; j++) {
            if (core_times[j] < core_times[min_core_index]) {
                min_core_index = j;
            }
        }
        
        // Assign the file to the selected core
        core_times[min_core_index] += files[i];
    }
    
    // Find the time when the last file completes
    long long max_time = core_times[0];
    for (int i = 1; i < numCores; i++) {
        if (core_times[i] > max_time) {
            max_time = core_times[i];
        }
    }
    
    free(core_times);
    return max_time;
}

int main() {
    // --- Test Case 1 ---
    printf("Test Case 1:\n");
    int files1[] = {3, 1, 4, 1, 5, 9, 2, 6};
    int n1 = sizeof(files1) / sizeof(files1[0]);
    int num_cores1 = 3;
    long long result1 = processFiles(files1, n1, num_cores1);
    printf("Inputs: files=[3, 1, 4, 1, 5, 9, 2, 6], numCores=3\n");
    printf("Expected: 9\n"); // Optimal distribution to minimize max finish time
    printf("Actual: %lld\n\n", result1);

    // --- Test Case 2 ---
    printf("Test Case 2:\n");
    int files2[] = {10, 20, 30, 40, 50};
    int n2 = sizeof(files2) / sizeof(files2[0]);
    int num_cores2 = 2;
    long long result2 = processFiles(files2, n2, num_cores2);
    printf("Inputs: files=[10, 20, 30, 40, 50], numCores=2\n");
    printf("Expected: 80\n"); // Optimal distribution: [10,30,50],[20,40]
    printf("Actual: %lld\n\n", result2);

    return 0;
}
