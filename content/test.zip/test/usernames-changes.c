#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char** possibleChanges(char** usernames, int usernames_count) {
    char** result = malloc(usernames_count * sizeof(char*));
    
    for(int i = 0; i < usernames_count; i++) {
        if(strlen(usernames[i]) <= 1) {
            result[i] = strdup("NO");
            continue;
        }
        
        int found = 0;
        for(int j = 0; j < strlen(usernames[i]) - 1; j++) {
            if(usernames[i][j] > usernames[i][j + 1]) {
                result[i] = strdup("YES");
                found = 1;
                break;
            }
        }
        if(!found) {
            result[i] = strdup("NO");
        }
    }
    return result;
}

void runTestCase(char** usernames, int count, char** expected) {
    printf("\nTest Case:\n");
    printf("Usernames: ");
    for(int i = 0; i < count; i++) printf("%s ", usernames[i]);
    
    char** result = possibleChanges(usernames, count);
    
    printf("\nExpected: ");
    for(int i = 0; i < count; i++) printf("%s ", expected[i]);
    printf("\nActual: ");
    for(int i = 0; i < count; i++) printf("%s ", result[i]);
    
    int passed = 1;
    for(int i = 0; i < count; i++) {
        if(strcmp(result[i], expected[i]) != 0) {
            passed = 0;
            break;
        }
    }
    printf("\nResult: %s\n", passed ? "✓ PASSED" : "✗ FAILED");
    
    for(int i = 0; i < count; i++) free(result[i]);
    free(result);
}

int main() {
    char* usernames1[] = {"foo", "bar", "baz"};
    char* expected1[] = {"NO", "NO", "NO"};
    runTestCase(usernames1, 3, expected1);

    char* usernames2[] = {"bee", "superhero", "ace"};
    char* expected2[] = {"YES", "YES", "NO"};
    runTestCase(usernames2, 3, expected2);
    
    return 0;
}
