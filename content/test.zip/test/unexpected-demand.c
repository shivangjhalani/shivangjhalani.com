#include <stdio.h>
#include <stdlib.h>

// Comparison function for qsort
int compare(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

int filledOrders(int* order, int order_count, int k) {
    qsort(order, order_count, sizeof(int), compare);
    int ans = 0;
    
    for(int i = 0; i < order_count; i++) {
        if(order[i] <= k) {
            ans++;
            k -= order[i];
        } else {
            break;
        }
    }
    return ans;
}

void runTestCase(int* order, int count, int k, int expected) {
    printf("\nTest Case:\n");
    printf("Orders: ");
    for(int i = 0; i < count; i++) printf("%d ", order[i]);
    printf("\nCapacity: %d\n", k);
    
    int result = filledOrders(order, count, k);
    printf("Expected: %d\n", expected);
    printf("Actual: %d\n", result);
    printf("Result: %s\n", result == expected ? "✓ PASSED" : "✗ FAILED");
}

int main() {
    int order1[] = {10, 30};
    runTestCase(order1, 2, 40, 2);

    int order2[] = {5, 4, 6};
    runTestCase(order2, 3, 3, 0);
    
    return 0;
}
