#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> // For isdigit, islower, isupper

// Function for password decryption
char* decryptPassword(char* s) {
    int n = strlen(s);
    char* result = (char*)malloc((n + 1) * sizeof(char));
    if (!result) return NULL;
    
    int write_index = 0;
    int read_index = 0;
    
    // Store digits to use later
    char digits[n];
    int digit_count = 0;
    
    // First pass: collect digits from the beginning
    while (read_index < n && isdigit(s[read_index])) {
        digits[digit_count++] = s[read_index++];
    }
    
    // Second pass: process the rest of the string
    while (read_index < n) {
        // Case: lowercase followed by uppercase followed by asterisk
        if (read_index + 2 < n && 
            islower(s[read_index]) && 
            isupper(s[read_index+1]) && 
            s[read_index+2] == '*') {
            
            result[write_index++] = s[read_index+1]; // Write uppercase
            result[write_index++] = s[read_index];   // Write lowercase
            read_index += 3;  // Skip all three characters
        }
        // Case: zero (which means substitute with a digit)
        else if (s[read_index] == '0') {
            if (digit_count > 0) {
                result[write_index++] = digits[--digit_count];
            }
            read_index++;
        }
        // Default case: copy the character
        else {
            result[write_index++] = s[read_index++];
        }
    }
    
    result[write_index] = '\0';
    return result;
}

int main() {
    // --- Test Case 1 (From image) ---
    printf("Test Case 1:\n");
    char s1[] = "51Pa*0Lp*0e"; // Encrypted string
    char* result1 = decryptPassword(s1);
    printf("Input: \"%s\"\n", s1);
    printf("Expected: \"aP1pL5e\"\n");
    printf("Actual: \"%s\"\n\n", result1 ? result1 : "NULL");
    free(result1);

    // --- Test Case 2 (From image) ---
    printf("Test Case 2:\n");
    char s2[] = "pTo*Ta*O"; // Encrypted string
    char* result2 = decryptPassword(s2);
    printf("Input: \"%s\"\n", s2);
    printf("Expected: \"poTaTO\"\n");
    printf("Actual: \"%s\"\n\n", result2 ? result2 : "NULL");
    free(result2);

    // --- Test Case 3 (Additional Test) ---
    printf("Test Case 3:\n");
    char s3[] = "1Bl*Ab*";
    char* result3 = decryptPassword(s3);
    printf("Input: \"%s\"\n", s3);
    printf("Expected: \"lBAb1\"\n");
    printf("Actual: \"%s\"\n\n", result3 ? result3 : "NULL");
    free(result3);

    return 0;
}
