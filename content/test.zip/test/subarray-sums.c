#include <stdio.h>
#include <stdlib.h>

long* findSum(int* numbers, int numbers_count, int** queries, int queries_rows) {
    // Create prefix sum arrays
    long* prefix_sum = malloc((numbers_count + 1) * sizeof(long));
    long* zero_count = malloc((numbers_count + 1) * sizeof(long));
    prefix_sum[0] = 0;
    zero_count[0] = 0;
    
    for(int i = 0; i < numbers_count; i++) {
        prefix_sum[i + 1] = prefix_sum[i] + numbers[i];
        zero_count[i + 1] = zero_count[i] + (numbers[i] == 0 ? 1 : 0);
    }
    
    long* result = malloc(queries_rows * sizeof(long));
    for(int i = 0; i < queries_rows; i++) {
        int l = queries[i][0];
        int r = queries[i][1];
        int x = queries[i][2];
        result[i] = prefix_sum[r] - prefix_sum[l - 1] + 
                    x * (zero_count[r] - zero_count[l - 1]);
    }
    
    free(prefix_sum);
    free(zero_count);
    return result;
}

void runTestCase(int* numbers, int num_count, int** queries, int query_count, long* expected) {
    printf("\nTest Case:\n");
    printf("Numbers: ");
    for(int i = 0; i < num_count; i++) printf("%d ", numbers[i]);
    printf("\nQueries:\n");
    for(int i = 0; i < query_count; i++) 
        printf("L=%d R=%d X=%d\n", queries[i][0], queries[i][1], queries[i][2]);
    
    long* result = findSum(numbers, num_count, queries, query_count);
    
    printf("Expected: ");
    for(int i = 0; i < query_count; i++) printf("%ld ", expected[i]);
    printf("\nActual: ");
    for(int i = 0; i < query_count; i++) printf("%ld ", result[i]);
    
    int passed = 1;
    for(int i = 0; i < query_count; i++) {
        if(result[i] != expected[i]) {
            passed = 0;
            break;
        }
    }
    printf("\nResult: %s\n", passed ? "✓ PASSED" : "✗ FAILED");
    free(result);
}

int main() {
    int numbers[] = {5, 0, 0, 2, 3};
    int* queries[] = {
        (int[]){1, 3, 2},
        (int[]){2, 4, 1}
    };
    long expected[] = {9, 5};
    runTestCase(numbers, 5, queries, 2, expected);
    
    return 0;
}
