#include <stdio.h>
#include <stdlib.h>

int longestSubarray(int* arr, int arr_count) {
    int max_len = 0;
    
    for(int i = 0; i < arr_count; i++) {
        int min_val = arr[i];
        int max_val = arr[i];
        
        for(int j = i; j < arr_count; j++) {
            if(arr[j] < min_val) min_val = arr[j];
            if(arr[j] > max_val) max_val = arr[j];
            
            if(max_val - min_val <= 1) {
                int len = j - i + 1;
                if(len > max_len) max_len = len;
            } else {
                break;
            }
        }
    }
    
    return max_len;
}

void runTestCase(int* arr, int size, int expected) {
    printf("\nInput Array: ");
    for(int i = 0; i < size; i++) printf("%d ", arr[i]);
    printf("\n");
    
    int result = longestSubarray(arr, size);
    printf("Expected Output: %d\n", expected);
    printf("Actual Output: %d\n", result);
    printf("Result: %s\n", result == expected ? "✓ PASSED" : "✗ FAILED");
}

int main() {
    // Test Case 1
    int arr1[] = {1, 1, 1, 3, 3, 2, 2};
    runTestCase(arr1, 7, 4);  // Expected: 4 (subarray [1,1,1,2] or [2,2,3,3])
    
    // Test Case 2
    int arr2[] = {1, 2, 3, 4, 5};
    runTestCase(arr2, 5, 2);  // Expected: 2 (any adjacent pair)
    
    return 0;
}
