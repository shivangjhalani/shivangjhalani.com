#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define structure for trader counts
typedef struct {
  char *name;
  int count;
} TraderCount;

// Comparison function for qsort if sorting trader names at the end
int compareStrings(const void *a, const void *b) {
  return strcmp(*(const char **)a, *(const char **)b);
}

// Placeholder function for the core logic
char **findActiveTraders(int n_trades, char **trades, int threshold_percent,
                         int *result_count) {
  // BASE CSE
  if (n_trades <= 0 || !trades) {
    *result_count = 0;
    return NULL;
  }

  qsort(trades, n_trades, sizeof(char *), compareStrings);

  char **active = NULL;
  char *prev = NULL;
  int count = 0;
  *result_count = 0;
  double threshold = (threshold_percent / 100.0) * n_trades;

  for (int i = 0; i < n_trades; i++) {
    if (prev && strcmp(trades[i], prev) == 0) {
      count++;
    } else {
      if (prev && count >= threshold) {
        active = realloc(active, (*result_count + 1) * sizeof(char *));
        if (!active) {
          *result_count = 0;
          return NULL;
        }
        active[*result_count] = strdup(prev);
        *result_count += 1;
      }
      count = 1;
    }
    prev = trades[i];
  }

  if (count >= threshold) {
    active = realloc(active, (*result_count + 1) * sizeof(char *));
    if (!active) {
      *result_count = 0;
      return NULL;
    }
    active[*result_count] = strdup(prev);
    (*result_count)++;
  }

  return active;  
}

int main() {
  // --- Test Case 1 (From image) ---
  printf("Test Case 1:\n");
  char *trades1[] = {"Omega", "Alpha", "Omega", "Alpha", "Omega", "Beta"};
  int n1 = sizeof(trades1) / sizeof(trades1[0]);
  int thresh1 = 5; // 5% threshold
  int count1;
  char **result1 = findActiveTraders(n1, trades1, thresh1, &count1);
  printf("Inputs: trades=[\"Omega\", \"Alpha\", \"Omega\", \"Alpha\", "
         "\"Omega\", \"Beta\"], threshold=5\n");
  printf(
      "Expected: [\"Alpha\", \"Beta\", \"Omega\"]\n"); // Sorted alphabetically
  printf("Actual: [");
  if (result1) {
    for (int i = 0; i < count1; ++i) {
      printf("\"%s\"%s", result1[i], (i == count1 - 1) ? "" : ", ");
      free(result1[i]); // Free individual strings
    }
    free(result1); // Free the array itself
  } else {
    printf("Allocation failed");
  }
  printf("]\n\n");

  // --- Test Case 2 (From image) ---
  printf("Test Case 2:\n");
  char *trades2[] = {"Alpha", "Beta",    "Zeta",  "Beta", "Zeta",
                     "Zeta",  "Epsilon", "Beta",  "Zeta", "Beta",
                     "Zeta",  "Beta",    "Delta", "Zeta", "Beta",
                     "Zeta",  "Beta",    "Zeta",  "Beta", "Delta"};
  int n2 = sizeof(trades2) / sizeof(trades2[0]);
  int thresh2 = 20; // 20% threshold
  int count2;
  char **result2 = findActiveTraders(n2, trades2, thresh2, &count2);
  printf("Inputs: trades=[\"Alpha\", \"Beta\", \"Zeta\", ...], threshold=20\n");
  printf("Expected: [\"Beta\", \"Zeta\"]\n"); // Only Beta and Zeta exceed 20%
  printf("Actual: [");
  if (result2) {
    for (int i = 0; i < count2; ++i) {
      printf("\"%s\"%s", result2[i], (i == count2 - 1) ? "" : ", ");
      free(result2[i]);
    }
    free(result2);
  } else {
    printf("Allocation failed");
  }
  printf("]\n\n");

  return 0;
}
