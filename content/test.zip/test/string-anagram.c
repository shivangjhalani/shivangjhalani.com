#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHAR_SIZE 26
#define MAX_NAME 100

void getFrequency(char* str, int* freq) {
    memset(freq, 0, CHAR_SIZE * sizeof(int));
    for(int i = 0; str[i]; i++) {
        freq[str[i] - 'a']++;
    }
}

int* stringAnagram(char** dictionary, int dictionary_count, char** query, int query_count) {
    int* result = (int*)calloc(query_count, sizeof(int));
    int** dict_freq = (int**)malloc(dictionary_count * sizeof(int*));
    
    // Precompute frequencies for dictionary words
    for(int i = 0; i < dictionary_count; i++) {
        dict_freq[i] = (int*)malloc(CHAR_SIZE * sizeof(int));
        getFrequency(dictionary[i], dict_freq[i]);
    }
    
    // Check each query
    for(int i = 0; i < query_count; i++) {
        int query_freq[CHAR_SIZE];
        getFrequency(query[i], query_freq);
        
        for(int j = 0; j < dictionary_count; j++) {
            int match = 1;
            for(int k = 0; k < CHAR_SIZE; k++) {
                if(query_freq[k] != dict_freq[j][k]) {
                    match = 0;
                    break;
                }
            }
            result[i] += match;
        }
    }
    
    // Cleanup
    for(int i = 0; i < dictionary_count; i++) {
        free(dict_freq[i]);
    }
    free(dict_freq);
    
    return result;
}

void runTestCase(char** dict, int dict_size, char** queries, int query_size, int* expected) {
    printf("\nTest Case:\n");
    printf("Dictionary: ");
    for(int i = 0; i < dict_size; i++) printf("%s ", dict[i]);
    printf("\nQueries: ");
    for(int i = 0; i < query_size; i++) printf("%s ", queries[i]);
    
    int* result = stringAnagram(dict, dict_size, queries, query_size);
    
    printf("\nExpected: ");
    for(int i = 0; i < query_size; i++) printf("%d ", expected[i]);
    printf("\nActual: ");
    for(int i = 0; i < query_size; i++) printf("%d ", result[i]);
    
    int passed = 1;
    for(int i = 0; i < query_size; i++) {
        if(result[i] != expected[i]) {
            passed = 0;
            break;
        }
    }
    printf("\nResult: %s\n", passed ? "✓ PASSED" : "✗ FAILED");
    free(result);
}

int main() {
    char* dict1[] = {"hack", "hackerrank", "hackers", "hacking"};
    char* query1[] = {"hacker", "rank"};
    int expected1[] = {2, 0};
    runTestCase(dict1, 4, query1, 2, expected1);

    char* dict2[] = {"heater", "cold", "clod", "reheat", "docl"};
    char* query2[] = {"codl", "heater", "abcd"};
    int expected2[] = {3, 2, 0};
    runTestCase(dict2, 5, query2, 3, expected2);
    return 0;
}
