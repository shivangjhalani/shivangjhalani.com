#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// Helper function to check if a character is a vowel
bool is_vowel(char c) {
    return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
}

// Find the lexicographically smallest vowel substring of length k
char* findSubstring(char* s, int k) {
    int n = strlen(s);
    static char not_found[] = "Not found!";
    static char result[1001]; // Assuming max k is 1000
    
    if (k <= 0 || k > n) {
        return not_found;
    }
    
    bool found = false;
    bool foundVowel = false;
    
    // Try each possible substring of length k
    for (int i = 0; i <= n - k; i++) {
        bool has_vowel = false;
        
        // Check if this substring contains at least one vowel
        for (int j = 0; j < k; j++) {
            if (is_vowel(s[i + j])) {
                has_vowel = true;
                break;
            }
        }
        
        if (has_vowel) {
            foundVowel = true;
            
            // If this is the first valid substring, store it
            if (!found) {
                strncpy(result, s + i, k);
                result[k] = '\0';
                found = true;
            } else {
                // Otherwise, compare and update if this one is lexicographically smaller
                if (strncmp(s + i, result, k) < 0) {
                    strncpy(result, s + i, k);
                    result[k] = '\0';
                }
            }
        }
    }
    
    if (found) {
        return result;
    } else {
        return not_found;
    }
}

int main() {
    // --- Test Case 1 ---
    printf("Test Case 1:\n");
    char s1[] = "azerdii";
    int k1 = 5;
    char* result1 = findSubstring(s1, k1);
    printf("Input: s=\"%s\", k=%d\n", s1, k1);
    printf("Expected: \"erdii\"\n");
    printf("Actual: \"%s\"\n\n", result1);

    // --- Test Case 2 ---
    printf("Test Case 2:\n");
    char s2[] = "qwdftr";
    int k2 = 2;
    char* result2 = findSubstring(s2, k2);
    printf("Input: s=\"%s\", k=%d\n", s2, k2);
    printf("Expected: \"Not found!\"\n");
    printf("Actual: \"%s\"\n\n", result2);

    // --- Test Case 3 ---
    printf("Test Case 3:\n");
    char s3[] = "aeiou";
    int k3 = 2;
    char* result3 = findSubstring(s3, k3);
    printf("Input: s=\"%s\", k=%d\n", s3, k3);
    printf("Expected: \"ae\"\n");
    printf("Actual: \"%s\"\n\n", result3);

    // --- Test Case 4 ---
    printf("Test Case 4:\n");
    char s4[] = "cuaieuouac";
    int k4 = 4;
    char* result4 = findSubstring(s4, k4);
    printf("Input: s=\"%s\", k=%d\n", s4, k4);
    printf("Expected: \"aieu\"\n");
    printf("Actual: \"%s\"\n\n", result4);

    return 0;
}
