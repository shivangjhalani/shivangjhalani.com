#include <stdio.h>
#include <stdlib.h>

int compare_desc(const void* a, const void* b) {
    return (*(int*)b - *(int*)a);
}

long minTime(int* files, int files_count, int numCores, int limit) {
    int* divisible = malloc(files_count * sizeof(int));
    int* non_divisible = malloc(files_count * sizeof(int));
    int div_count = 0, non_div_count = 0;
    
    // Separate files into divisible and non-divisible by numCores
    for(int i = 0; i < files_count; i++) {
        if(files[i] % numCores == 0) {
            divisible[div_count++] = files[i];
        } else {
            non_divisible[non_div_count++] = files[i];
        }
    }
    
    qsort(divisible, div_count, sizeof(int), compare_desc);
    
    long total_time = 0;
    for(int i = 0; i < div_count; i++) {
        if(i < limit) {
            total_time += divisible[i] / numCores;
        } else {
            total_time += divisible[i];
        }
    }
    
    for(int i = 0; i < non_div_count; i++) {
        total_time += non_divisible[i];
    }
    
    free(divisible);
    free(non_divisible);
    return total_time;
}

void runTestCase(int* files, int count, int numCores, int limit, long expected) {
    printf("\nTest Case:\n");
    printf("Files: ");
    for(int i = 0; i < count; i++) printf("%d ", files[i]);
    printf("\nNum Cores: %d, Limit: %d\n", numCores, limit);
    
    long result = minTime(files, count, numCores, limit);
    printf("Expected: %ld\n", expected);
    printf("Actual: %ld\n", result);
    printf("Result: %s\n", result == expected ? "✓ PASSED" : "✗ FAILED");
}

int main() {
    int files1[] = {3, 1, 2, 4, 1, 2};
    runTestCase(files1, 6, 2, 2, 7);

    int files2[] = {4, 1, 3, 2, 8};
    runTestCase(files2, 5, 2, 2, 11);
    
    return 0;
}
