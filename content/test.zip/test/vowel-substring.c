#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* findSubstring(char* s, int k) {
    char vowels[] = "aeiou";
    int len = strlen(s);
    int best = 0;
    int bestIndex = -1;
    
    // Count initial window
    int cur = 0;
    for(int i = 0; i < k; i++) {
        for(int v = 0; v < 5; v++) {
            if(s[i] == vowels[v]) {
                cur++;
                break;
            }
        }
    }
    best = cur;
    
    // Slide window
    for(int i = k; i < len; i++) {
        // Remove leftmost character
        for(int v = 0; v < 5; v++) {
            if(s[i-k] == vowels[v]) {
                cur--;
                break;
            }
        }
        // Add new character
        for(int v = 0; v < 5; v++) {
            if(s[i] == vowels[v]) {
                cur++;
                break;
            }
        }
        if(cur > best) {
            best = cur;
            bestIndex = i-k+1;
        }
    }
    
    if(best > 0) {
        char* result = (char*)malloc((k+1) * sizeof(char));
        strncpy(result, &s[bestIndex], k);
        result[k] = '\0';
        return result;
    } else {
        char* result = strdup("Not found!");
        return result;
    }
}

void runTestCase(char* s, int k, char* expected) {
    printf("\nTest Case:\n");
    printf("String: %s\n", s);
    printf("K: %d\n", k);
    
    char* result = findSubstring(s, k);
    printf("Expected: %s\n", expected);
    printf("Actual: %s\n", result);
    printf("Result: %s\n", strcmp(result, expected) == 0 ? "✓ PASSED" : "✗ FAILED");
    free(result);
}

int main() {
    runTestCase("caberqiitefg", 5, "erqii");
    runTestCase("aeiouia", 3, "aei");
    runTestCase("azerdii", 5, "erdii");
    
    return 0;
}
