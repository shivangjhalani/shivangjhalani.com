#include <stdio.h>
#include <stdlib.h>
#include <limits.h> // For INT_MAX
#include <math.h>   // For abs

// Define structure for adjacency list if needed
typedef struct Node {
    int id;
    struct Node* next;
} Node;

// Global or passed variables for DFS
long long* subtree_sums = NULL;
int* file_sizes = NULL;
Node** adj = NULL;
long long total_sum = 0;
long long min_diff = LLONG_MAX; // Use long long for differences

// DFS function to calculate subtree sums
void dfs(int u, int p) {
    subtree_sums[u] = file_sizes[u];
    Node* current = adj[u];
    while (current != NULL) {
        int v = current->id;
        if (v != p) {
            dfs(v, u);
            subtree_sums[u] += subtree_sums[v];
        }
        current = current->next;
    }
    // Calculate difference if we cut the edge between u and its parent (p)
    if (p != -1) { // Don't calculate for the root's non-existent parent edge
        long long diff = llabs(total_sum - 2 * subtree_sums[u]);
        if (diff < min_diff) {
            min_diff = diff;
        }
    }
}

// Helper to add edge to adjacency list
void addEdge(int u, int v) {
    Node* newNodeV = (Node*)malloc(sizeof(Node));
    newNodeV->id = v;
    newNodeV->next = adj[u];
    adj[u] = newNodeV;

    Node* newNodeU = (Node*)malloc(sizeof(Node));
    newNodeU->id = u;
    newNodeU->next = adj[v];
    adj[v] = newNodeU;
}

// Function signature updated based on typical inputs for this problem
// parent: array where parent[i] is the parent of node i (-1 for root)
// n: number of nodes (size of parent and file_size arrays)
// file_size_in: array of file sizes for each node
// Returns the minimum absolute difference between total sizes of two partitions after removing one edge
int findSplitPoint(int n, int* parent, int* file_size_in) {
    // Reset global state for multiple calls if necessary
    total_sum = 0;
    min_diff = LLONG_MAX;

    // Allocate memory
    adj = (Node**)calloc(n, sizeof(Node*)); // Initialize to NULL
    subtree_sums = (long long*)malloc(n * sizeof(long long));
    file_sizes = file_size_in; // Use the input directly

    if (!adj || !subtree_sums) {
        // Handle allocation failure
        free(adj);
        free(subtree_sums);
        return -1; // Or some error code
    }

    // Build adjacency list and calculate total sum
    int root = -1;
    for (int i = 0; i < n; ++i) {
        total_sum += file_sizes[i];
        if (parent[i] != -1) {
            addEdge(i, parent[i]);
        } else {
            root = i;
        }
    }

    // Perform DFS from the root
    if (root != -1) {
        dfs(root, -1);
    } else {
        // Handle case with no root or disconnected graph if necessary
        // For this problem structure, a root usually exists.
    }


    // Free allocated memory
    for(int i=0; i<n; ++i) {
        Node* current = adj[i];
        while(current != NULL) {
            Node* temp = current;
            current = current->next;
            free(temp);
        }
    }
    free(adj);
    free(subtree_sums);
    adj = NULL;
    subtree_sums = NULL;
    file_sizes = NULL;


    return (int)min_diff; // Cast result back to int as per typical return type
}

int main() {
    // --- Test Case 1 (From image) ---
    printf("Test Case 1:\n");
    int parent1[] = {-1, 0, 0, 1, 1, 2};
    int file_size1[] = {1, 2, 2, 1, 1, 1};
    int n1 = sizeof(parent1) / sizeof(parent1[0]);
    int result1 = findSplitPoint(n1, parent1, file_size1);
    printf("Inputs: parent=[-1, 0, 0, 1, 1, 2], file_size=[1, 2, 2, 1, 1, 1]\n");
    printf("Expected: 0\n"); // Total=8. Cut 0-1: |8-2*4|=0. Cut 0-2: |8-2*3|=2. Cut 1-3: |8-2*1|=6. Cut 1-4: |8-2*1|=6. Cut 2-5: |8-2*1|=6. Min is 0.
    printf("Actual: %d\n\n", result1);


    // --- Test Case 2 (Example) ---
    printf("Test Case 2:\n");
    int parent2[] = {-1, 0, 1, 1};
    int file_size2[] = {10, 2, 3, 4};
    int n2 = sizeof(parent2) / sizeof(parent2[0]);
    int result2 = findSplitPoint(n2, parent2, file_size2);
    printf("Inputs: parent=[-1, 0, 1, 1], file_size=[10, 2, 3, 4]\n");
    printf("Expected: 1\n"); // Total=19. Cut 0-1: |19-2*(2+3+4)|=|19-18|=1. Cut 1-2: |19-2*3|=13. Cut 1-3: |19-2*4|=11. Min is 1.
    printf("Actual: %d\n\n", result2);

    // Add more test cases as needed

    return 0;
}
