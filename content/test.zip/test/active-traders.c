#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAME 100

int compare_str(const void* a, const void* b) {
    return strcmp(*(const char**)a, *(const char**)b);
}

char** mostActive(char** customers, int customers_count, int* result_count) {
    // Count occurrences
    char** unique = malloc(customers_count * sizeof(char*));
    int* counts = calloc(customers_count, sizeof(int));
    int unique_count = 0;
    
    for(int i = 0; i < customers_count; i++) {
        int found = 0;
        for(int j = 0; j < unique_count; j++) {
            if(strcmp(customers[i], unique[j]) == 0) {
                counts[j]++;
                found = 1;
                break;
            }
        }
        if(!found) {
            unique[unique_count] = strdup(customers[i]);
            counts[unique_count]++;
            unique_count++;
        }
    }
    
    // Filter and sort results
    char** result = malloc(unique_count * sizeof(char*));
    *result_count = 0;
    float threshold = customers_count * 0.05;
    
    for(int i = 0; i < unique_count; i++) {
        if(counts[i] >= threshold) {
            result[*result_count] = strdup(unique[i]);
            (*result_count)++;
        }
    }
    
    qsort(result, *result_count, sizeof(char*), compare_str);
    
    // Cleanup
    for(int i = 0; i < unique_count; i++) {
        free(unique[i]);
    }
    free(unique);
    free(counts);
    
    return result;
}

void runTestCase(char** customers, int count, char** expected, int expected_count) {
    printf("\nTest Case:\n");
    printf("Customers: ");
    for(int i = 0; i < count; i++) printf("%s ", customers[i]);
    
    int result_count;
    char** result = mostActive(customers, count, &result_count);
    
    printf("\nExpected: ");
    for(int i = 0; i < expected_count; i++) printf("%s ", expected[i]);
    printf("\nActual: ");
    for(int i = 0; i < result_count; i++) printf("%s ", result[i]);
    
    int passed = (result_count == expected_count);
    if(passed) {
        for(int i = 0; i < result_count; i++) {
            if(strcmp(result[i], expected[i]) != 0) {
                passed = 0;
                break;
            }
        }
    }
    printf("\nResult: %s\n", passed ? "✓ PASSED" : "✗ FAILED");
    
    for(int i = 0; i < result_count; i++) free(result[i]);
    free(result);
}

int main() {
    char* customers1[] = {"Alpha", "Beta", "Alpha", "Alpha", "Beta"};
    char* expected1[] = {"Alpha", "Beta"};
    runTestCase(customers1, 5, expected1, 2);
    
    char* customers2[] = {"Omega", "Alpha", "Omega", "Alpha", "Omega", "Alpha"};
    char* expected2[] = {"Alpha", "Omega"};
    runTestCase(customers2, 6, expected2, 2);
    return 0;
}
