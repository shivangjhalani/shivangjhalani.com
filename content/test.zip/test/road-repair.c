#include <stdio.h>
#include <stdlib.h>

int compare(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

long getMinCost(int* crew_id, int crew_id_count, int* job_id, int job_id_count) {
    qsort(crew_id, crew_id_count, sizeof(int), compare);
    qsort(job_id, job_id_count, sizeof(int), compare);
    
    long total_cost = 0;
    for(int i = 0; i < crew_id_count; i++) {
        total_cost += abs(crew_id[i] - job_id[i]);
    }
    return total_cost;
}

void runTestCase(int* crew_id, int* job_id, int count, long expected) {
    printf("\nTest Case:\n");
    printf("Crew IDs: ");
    for(int i = 0; i < count; i++) printf("%d ", crew_id[i]);
    printf("\nJob IDs: ");
    for(int i = 0; i < count; i++) printf("%d ", job_id[i]);
    
    long result = getMinCost(crew_id, count, job_id, count);
    printf("\nExpected: %ld\n", expected);
    printf("Actual: %ld\n", result);
    printf("Result: %s\n", result == expected ? "✓ PASSED" : "✗ FAILED");
}

int main() {
    int crew1[] = {5, 3, 1, 4, 6};
    int job1[] = {9, 8, 3, 15, 1};
    runTestCase(crew1, job1, 5, 17);

    int crew2[] = {1, 2, 3};
    int job2[] = {4, 5, 6};
    runTestCase(crew2, job2, 3, 9);
    
    return 0;
}
