#include <stdio.h>
#include <stdlib.h>

// Function signature updated based on typical inputs for this problem
// initial_stock: the starting number of items (k in the image)
// n_orders: number of orders in the array
// orders: array containing the quantity for each order
// Returns the final stock level after processing all possible orders
int calculateFulfilledOrders(int initial_stock, int n_orders, int* orders) {
    int current_stock = initial_stock;
    for (int i = 0; i < n_orders; ++i) {
        if (orders[i] <= current_stock) {
            current_stock -= orders[i];
        } else {
            // Not enough stock for this order, stop processing
            break;
        }
    }
    return current_stock;
}

int main() {
    // --- Test Case 1 (From image) ---
    printf("Test Case 1:\n");
    int orders1[] = {10, 20, 30, 40, 50};
    int n1 = sizeof(orders1) / sizeof(orders1[0]);
    int stock1 = 100;
    int result1 = calculateFulfilledOrders(stock1, n1, orders1);
    printf("Inputs: orders=[10, 20, 30, 40, 50], initial_stock=100\n");
    printf("Expected: 0\n"); // 100 - 10 = 90; 90 - 20 = 70; 70 - 30 = 40; 40 - 40 = 0; Cannot fulfill 50. Final stock = 0.
    printf("Actual: %d\n\n", result1);


    // --- Test Case 2 (From image) ---
    printf("Test Case 2:\n");
    int orders2[] = {10, 30};
    int n2 = sizeof(orders2) / sizeof(orders2[0]);
    int stock2 = 20;
    int result2 = calculateFulfilledOrders(stock2, n2, orders2);
    printf("Inputs: orders=[10, 30], initial_stock=20\n");
    printf("Expected: 10\n"); // 20 - 10 = 10; Cannot fulfill 30. Final stock = 10.
    printf("Actual: %d\n\n", result2);

    // --- Test Case 3 (Empty orders) ---
    printf("Test Case 3:\n");
    int* orders3 = NULL;
    int n3 = 0;
    int stock3 = 50;
    int result3 = calculateFulfilledOrders(stock3, n3, orders3);
    printf("Inputs: orders=[], initial_stock=50\n");
    printf("Expected: 50\n");
    printf("Actual: %d\n\n", result3);


    return 0;
}
