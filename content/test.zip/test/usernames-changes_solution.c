#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// Function signature updated based on typical inputs for this problem
// n: number of usernames
// usernames: array of strings
// result_count: pointer to store the size of the returned array
// Returns an array of strings ("YES" or "NO") indicating if a change is possible
char** checkUsernames(int n, char** usernames, int* result_count) {
    *result_count = n;
    char** results = (char**)malloc(n * sizeof(char*));
    if (!results) {
        *result_count = 0;
        return NULL;
    }

    for (int i = 0; i < n; ++i) {
        char* current_name = usernames[i];
        int len = strlen(current_name);
        bool possible = false;
        // Check all single character swaps
        for (int j = 0; j < len - 1; ++j) {
             // We only need to check if ANY character is smaller than the one immediately following it.
             // If name[j] < name[j+1], then swapping them would result in a lexicographically smaller name.
             // However, the problem asks if *any* character can be swapped with *any other* character
             // to its left to make the string lexicographically smaller.
             // This is equivalent to checking if the string is already sorted in ascending order.
             // If it's NOT sorted, a smaller permutation exists.
             // A simpler check: iterate from right to left. Find the first char name[k]
             // which is smaller than the char to its right name[k+1]. If such k exists,
             // then a smaller permutation is possible.
             // Even simpler: just check if any character is smaller than any character to its left.
             for (int k = j + 1; k < len; ++k) {
                 if (current_name[j] > current_name[k]) {
                     possible = true;
                     break; // Found a possible swap
                 }
             }
             if (possible) break;
        }

        // The actual condition seems to be: can we change username[i] to make it lexicographically smaller?
        // This means: does there exist j < k such that username[i][j] > username[i][k]?
        // If yes, swapping them makes it smaller.
        possible = false; // Reset for the correct logic
        for(int j = 0; j < len; ++j) {
            for (int k = j + 1; k < len; ++k) {
                if (usernames[i][j] > usernames[i][k]) {
                    possible = true;
                    goto found_possibility; // Use goto for early exit from nested loops
                }
            }
        }

    found_possibility:
        if (possible) {
            results[i] = strdup("YES");
        } else {
            results[i] = strdup("NO");
        }
        // Check for strdup allocation failure
        if (!results[i]) {
            // Cleanup previously allocated strings
            for (int k = 0; k < i; ++k) free(results[k]);
            free(results);
            *result_count = 0;
            return NULL;
        }
    }

    return results;
}

int main() {
    // --- Test Case 1 (From image) ---
    printf("Test Case 1:\n");
    char* usernames1[] = {"bee", "superhero", "ace"};
    int n1 = sizeof(usernames1) / sizeof(usernames1[0]);
    int count1;
    char** result1 = checkUsernames(n1, usernames1, &count1);
    printf("Inputs: [\"bee\", \"superhero\", \"ace\"]\n");
    printf("Expected: [\"NO\", \"YES\", \"NO\"]\n"); // bee->NO, superhero->YES (e.g., supehreor), ace->NO
    printf("Actual: [");
    if (result1) {
        for(int i = 0; i < count1; ++i) {
            printf("\"%s\"%s", result1[i], (i == count1 - 1) ? "" : ", ");
            free(result1[i]); // Free individual strings
        }
        free(result1); // Free the array itself
    } else {
        printf("Allocation failed");
    }
    printf("]\n\n");


    // --- Test Case 2 (Example) ---
    printf("Test Case 2:\n");
    char* usernames2[] = {"zyxw", "aaaa", "ba"};
    int n2 = sizeof(usernames2) / sizeof(usernames2[0]);
    int count2;
    char** result2 = checkUsernames(n2, usernames2, &count2);
    printf("Inputs: [\"zyxw\", \"aaaa\", \"ba\"]\n");
    printf("Expected: [\"YES\", \"NO\", \"YES\"]\n"); // zyxw->YES (wxyz), aaaa->NO, ba->YES (ab)
    printf("Actual: [");
     if (result2) {
        for(int i = 0; i < count2; ++i) {
            printf("\"%s\"%s", result2[i], (i == count2 - 1) ? "" : ", ");
            free(result2[i]);
        }
        free(result2);
    } else {
        printf("Allocation failed");
    }
    printf("]\n\n");


    return 0;
}
