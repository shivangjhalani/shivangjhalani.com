#include <stdio.h>
#include <stdlib.h>

// Function to find maximum cost with constraint
int maxCost(int n, int* cost, int* labels, int daily_limit) {
    int max_cost = 0;
    
    // Check all contiguous subarrays
    for (int i = 0; i < n; i++) {
        int current_cost = 0;
        int legal_count = 0;
        
        for (int j = i; j < n; j++) {
            current_cost += cost[j];
            if (labels[j] == 1) {
                legal_count++;
            }
            
            // Check if this subarray exactly meets the constraint
            if (legal_count == daily_limit && current_cost > max_cost) {
                max_cost = current_cost;
            }
        }
    }
    
    return max_cost;
}

int main() {
    // --- Test Case 1 ---
    printf("Test Case 1:\n");
    int cost1[] = {2, 5, 3, 11, 1};
    int labels1[] = {1, 1, 0, 1, 0};
    int n1 = sizeof(cost1) / sizeof(cost1[0]);
    int limit1 = 2;
    int result1 = maxCost(n1, cost1, labels1, limit1);
    printf("Inputs: cost=[2, 5, 3, 11, 1], labels=[1, 1, 0, 1, 0], limit=2\n");
    printf("Expected: 19\n"); // Largest sum with exactly 2 legal items (5+3+11)
    printf("Actual: %d\n\n", result1);

    // --- Test Case 2 ---
    printf("Test Case 2:\n");
    int cost2[] = {0, 3, 5, 1, 6};
    int labels2[] = {0, 1, 1, 0, 1};
    int n2 = sizeof(cost2) / sizeof(cost2[0]);
    int limit2 = 2;
    int result2 = maxCost(n2, cost2, labels2, limit2);
    printf("Inputs: cost=[0, 3, 5, 1, 6], labels=[0, 1, 1, 0, 1], limit=2\n");
    printf("Expected: 12\n"); // Largest sum with exactly 2 legal items (5+1+6)
    printf("Actual: %d\n\n", result2);

    // --- Test Case 3 ---
    printf("Test Case 3:\n");
    int cost3[] = {10, 2, 3, 4, 5};
    int labels3[] = {1, 0, 0, 1, 0};
    int n3 = sizeof(cost3) / sizeof(cost3[0]);
    int limit3 = 1;
    int result3 = maxCost(n3, cost3, labels3, limit3);
    printf("Inputs: cost=[10, 2, 3, 4, 5], labels=[1, 0, 0, 1, 0], limit=1\n");
    printf("Expected: 10\n"); // Largest sum with exactly 1 legal item (10)
    printf("Actual: %d\n\n", result3);

    return 0;
}
