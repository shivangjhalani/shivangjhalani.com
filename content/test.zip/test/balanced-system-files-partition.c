#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

typedef struct Node {
    int value;
    struct Node** children;
    int child_count;
} Node;

long calculateSubtreeSum(Node* root) {
    long sum = root->value;
    for(int i = 0; i < root->child_count; i++) {
        sum += calculateSubtreeSum(root->children[i]);
    }
    return sum;
}

int mostBalancedPartition(int* parent, int* files_size, int n) {
    // Build tree
    Node** nodes = malloc(n * sizeof(Node*));
    for(int i = 0; i < n; i++) {
        nodes[i] = malloc(sizeof(Node));
        nodes[i]->value = files_size[i];
        nodes[i]->children = malloc(n * sizeof(Node*));
        nodes[i]->child_count = 0;
    }
    
    for(int i = 1; i < n; i++) {
        nodes[parent[i]]->children[nodes[parent[i]]->child_count++] = nodes[i];
    }
    
    // Calculate total sum
    long total_sum = calculateSubtreeSum(nodes[0]);
    
    // Find minimum difference
    int min_diff = INT_MAX;
    for(int i = 1; i < n; i++) {
        long subtree_sum = calculateSubtreeSum(nodes[i]);
        long diff = abs(total_sum - 2 * subtree_sum);
        if(diff < min_diff) min_diff = diff;
    }
    
    // Cleanup
    for(int i = 0; i < n; i++) {
        free(nodes[i]->children);
        free(nodes[i]);
    }
    free(nodes);
    
    return min_diff;
}

void runTestCase(int* parent, int* files_size, int n, int expected) {
    printf("\nParent Array: ");
    for(int i = 0; i < n; i++) printf("%d ", parent[i]);
    printf("\nFiles Size: ");
    for(int i = 0; i < n; i++) printf("%d ", files_size[i]);
    printf("\n");
    
    int result = mostBalancedPartition(parent, files_size, n);
    printf("Expected Output: %d\n", expected);
    printf("Actual Output: %d\n", result);
    printf("Result: %s\n", result == expected ? "✓ PASSED" : "✗ FAILED");
}

int main() {
    // Test Case 1
    int parent1[] = {-1, 0, 0, 1, 1, 2};
    int files1[] = {1, 2, 2, 1, 1, 1};
    runTestCase(parent1, files1, 6, 0);
    
    // Test Case 2
    int parent2[] = {-1, 0, 1, 2};
    int files2[] = {1, 4, 3, 4};
    runTestCase(parent2, files2, 4, 2);
    
    return 0;
}
