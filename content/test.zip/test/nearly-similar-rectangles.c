#include <stdio.h>
#include <stdlib.h>

long gcd(long a, long b) {
    return b == 0 ? a : gcd(b, a % b);
}

long nearlySimilarRectangles(int sides_rows, int sides_columns, long** sides) {
    // Store reduced ratios
    long* reduced_width = malloc(sides_rows * sizeof(long));
    long* reduced_height = malloc(sides_rows * sizeof(long));
    
    for(int i = 0; i < sides_rows; i++) {
        long g = gcd(sides[i][0], sides[i][1]);
        reduced_width[i] = sides[i][0] / g;
        reduced_height[i] = sides[i][1] / g;
    }
    
    // Count pairs
    long result = 0;
    for(int i = 0; i < sides_rows; i++) {
        for(int j = i + 1; j < sides_rows; j++) {
            if(reduced_width[i] == reduced_width[j] && 
               reduced_height[i] == reduced_height[j]) {
                result++;
            }
        }
    }
    
    free(reduced_width);
    free(reduced_height);
    return result;
}

int main() {
    int sides_rows, sides_columns;
    scanf("%d %d", &sides_rows, &sides_columns);
    
    long** sides = malloc(sides_rows * sizeof(long*));
    for(int i = 0; i < sides_rows; i++) {
        sides[i] = malloc(2 * sizeof(long));
        scanf("%ld %ld", &sides[i][0], &sides[i][1]);
    }
    
    printf("%ld\n", nearlySimilarRectangles(sides_rows, sides_columns, sides));
    
    for(int i = 0; i < sides_rows; i++) free(sides[i]);
    free(sides);
    return 0;
}
