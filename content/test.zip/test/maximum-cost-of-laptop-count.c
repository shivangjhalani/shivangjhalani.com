#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int maxCost(int* cost, char** labels, int count, int dailyCount) {
    int max_cost = 0;
    int current_cost = 0;
    int current_count = 0;
    
    for(int i = 0; i < count; i++) {
        current_cost += cost[i];
        
        if(strcmp(labels[i], "legal") == 0) {
            current_count++;
            if(current_count == dailyCount) {
                if(current_cost > max_cost) {
                    max_cost = current_cost;
                }
                current_cost = 0;
                current_count = 0;
            }
        }
    }
    
    return max_cost;
}

void runTestCase(int* cost, char** labels, int count, int dailyCount, int expected) {
    printf("\nTest Case:\n");
    printf("Costs: ");
    for(int i = 0; i < count; i++) printf("%d ", cost[i]);
    printf("\nLabels: ");
    for(int i = 0; i < count; i++) printf("%s ", labels[i]);
    printf("\nDaily Count: %d\n", dailyCount);
    
    int result = maxCost(cost, labels, count, dailyCount);
    printf("Expected: %d\n", expected);
    printf("Actual: %d\n", result);
    printf("Result: %s\n", result == expected ? "✓ PASSED" : "✗ FAILED");
}

int main() {
    int cost1[] = {0, 3, 2, 3, 4};
    char* labels1[] = {"legal", "legal", "illegal", "legal", "legal"};
    runTestCase(cost1, labels1, 5, 2, 5);

    int cost2[] = {2, 5, 3, 7, 11, 1, 6};
    char* labels2[] = {"legal", "illegal", "legal", "illegal", "legal", "illegal", "legal"};
    runTestCase(cost2, labels2, 7, 2, 18);
    return 0;
}
