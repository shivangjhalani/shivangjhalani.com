#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Helper function to check if two strings are anagrams
int areAnagrams(char* str1, char* str2) {
    if (strlen(str1) != strlen(str2)) {
        return 0;
    }
    
    // Use character counting approach
    int counts[26] = {0}; // Assuming lowercase English letters only
    
    for (int i = 0; str1[i]; i++) {
        counts[str1[i] - 'a']++;
    }
    
    for (int i = 0; str2[i]; i++) {
        counts[str2[i] - 'a']--;
    }
    
    // Check if all counts are zero
    for (int i = 0; i < 26; i++) {
        if (counts[i] != 0) {
            return 0;
        }
    }
    
    return 1;
}

// Function to find anagram matches between dictionary and query words
int* stringAnagram(int n_dict, char** dictionary, int n_query, char** query, int* result_count) {
    *result_count = n_query;
    int* results = (int*)calloc(n_query, sizeof(int));
    if (!results) {
        *result_count = 0;
        return NULL;
    }
    
    for (int i = 0; i < n_query; i++) {
        for (int j = 0; j < n_dict; j++) {
            if (areAnagrams(query[i], dictionary[j])) {
                results[i]++;
            }
        }
    }
    
    return results;
}

int main() {
    // --- Test Case 1 (From image) ---
    printf("Test Case 1:\n");
    char* dict1[] = {"heater", "cold", "clod", "reheat", "docl"};
    int n_dict1 = sizeof(dict1) / sizeof(dict1[0]);
    char* query1[] = {"cold", "heater", "abcd"};
    int n_query1 = sizeof(query1) / sizeof(query1[0]);
    int count1;
    int* result1 = stringAnagram(n_dict1, dict1, n_query1, query1, &count1);
    printf("Inputs: dict=[\"heater\", \"cold\", \"clod\", \"reheat\", \"docl\"], query=[\"cold\", \"heater\", \"abcd\"]\n");
    printf("Expected: [3, 2, 0]\n"); 
    printf("Actual: [");
    if (result1) {
        for(int i = 0; i < count1; ++i) {
            printf("%d%s", result1[i], (i == count1 - 1) ? "" : ", ");
        }
        free(result1);
    } else {
        printf("Allocation failed");
    }
    printf("]\n\n");

    // --- Test Case 2 (From image) ---
    printf("Test Case 2:\n");
    char* dict2[] = {"listen", "silent", "it", "is"};
    int n_dict2 = sizeof(dict2) / sizeof(dict2[0]);
    char* query2[] = {"listen", "is", "silent", "it"};
    int n_query2 = sizeof(query2) / sizeof(query2[0]);
    int count2;
    int* result2 = stringAnagram(n_dict2, dict2, n_query2, query2, &count2);
    printf("Inputs: dict=[\"listen\", \"silent\", \"it\", \"is\"], query=[\"listen\", \"is\", \"silent\", \"it\"]\n");
    printf("Expected: [2, 2, 2, 2]\n");
    printf("Actual: [");
    if (result2) {
        for(int i = 0; i < count2; ++i) {
            printf("%d%s", result2[i], (i == count2 - 1) ? "" : ", ");
        }
        free(result2);
    } else {
        printf("Allocation failed");
    }
    printf("]\n\n");

    return 0;
}
