#include <stdio.h>
#include <stdlib.h>

// Define structure for edges
typedef struct {
    int u, v, cost;
} Edge;

// Comparison function for qsort
int compareEdges(const void* a, const void* b) {
    return ((Edge*)a)->cost - ((Edge*)b)->cost;
}

// Union-Find data structure
int* parent;
int* rank;

// Initialize Union-Find data structure
void initUnionFind(int n) {
    parent = (int*)malloc((n + 1) * sizeof(int));
    rank = (int*)calloc(n + 1, sizeof(int));
    
    if (!parent || !rank) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    
    for (int i = 1; i <= n; i++) {
        parent[i] = i; // Each node is initially its own parent
    }
}

// Find operation with path compression
int find(int x) {
    if (parent[x] != x) {
        parent[x] = find(parent[x]); // Path compression
    }
    return parent[x];
}

// Union operation with rank
void unionSets(int x, int y) {
    int rootX = find(x);
    int rootY = find(y);
    
    if (rootX == rootY) return;
    
    if (rank[rootX] < rank[rootY]) {
        parent[rootX] = rootY;
    } else {
        parent[rootY] = rootX;
        if (rank[rootX] == rank[rootY]) {
            rank[rootX]++;
        }
    }
}

// Kruskal's algorithm for MST
long long minRepairCost(int n_cities, int n_roads, Edge* roads) {
    // Sort roads by cost
    qsort(roads, n_roads, sizeof(Edge), compareEdges);
    
    // Initialize Union-Find
    initUnionFind(n_cities);
    
    long long total_cost = 0;
    int edges_added = 0;
    
    // Process roads in ascending order of cost
    for (int i = 0; i < n_roads; i++) {
        int u = roads[i].u;
        int v = roads[i].v;
        
        if (find(u) != find(v)) {
            // This edge doesn't create a cycle
            unionSets(u, v);
            total_cost += roads[i].cost;
            edges_added++;
            
            // If we've added n_cities-1 edges, we've completed the MST
            if (edges_added == n_cities - 1) {
                break;
            }
        }
    }
    
    // Free memory
    free(parent);
    free(rank);
    
    // Check if we found a spanning tree
    if (edges_added < n_cities - 1) {
        return -1; // Not all cities can be connected
    }
    
    return total_cost;
}

int main() {
    // --- Test Case 1 ---
    printf("Test Case 1:\n");
    Edge roads1[] = {
        {1, 2, 6}, {1, 3, 3}, {1, 4, 4},
        {2, 3, 2}, {3, 4, 1}, {4, 5, 5}
    };
    int n_cities1 = 5;
    int n_roads1 = sizeof(roads1) / sizeof(roads1[0]);
    long long result1 = minRepairCost(n_cities1, n_roads1, roads1);
    printf("Inputs: n_cities=5, roads=[(1,2,6), (1,3,3), (1,4,4), (2,3,2), (3,4,1), (4,5,5)]\n");
    printf("Expected: 11\n"); // MST cost: 1 + 2 + 3 + 5 = 11
    printf("Actual: %lld\n\n", result1);

    // --- Test Case 2 ---
    printf("Test Case 2:\n");
    Edge roads2[] = {
        {1, 2, 3}, {2, 3, 4}, {3, 4, 5},
        {4, 5, 6}, {5, 6, 7}, {6, 1, 8}
    };
    int n_cities2 = 6;
    int n_roads2 = sizeof(roads2) / sizeof(roads2[0]);
    long long result2 = minRepairCost(n_cities2, n_roads2, roads2);
    printf("Inputs: n_cities=6, roads=[(1,2,3), (2,3,4), (3,4,5), (4,5,6), (5,6,7), (6,1,8)]\n");
    printf("Expected: 25\n"); // MST cost: 3 + 4 + 5 + 6 + 7 = 25
    printf("Actual: %lld\n\n", result2);

    return 0;
}
